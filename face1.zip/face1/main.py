import tkinter as tk
import subprocess #다른 파일 실행

# 창 생성
window = tk.Tk()
window.title("My GUI")  # 창 제목
window.geometry("640x450")  # 창 크기 (너비 x 높이)

# 라벨 추가
label = tk.Label(window, text="Open CV Project", font=("Arial", 16))
label.pack(pady=10)  # 위아래 여백 추가

#버튼 클릭시 다른 파일 실행 
def run_other1_script():
    subprocess.run(["python", "button1.py"])

def run_other2_script():
    subprocess.run(["python", "button2.py"])

# 버튼 클릭 이벤트 함수
def on_button1_click():
    label.config(text="얼굴인식")

def on_button2_click():
    label.config(text="표정인식")

def on_button3_click():
    label.config(text="얼굴등록")

# 버튼 추가
button = tk.Button(window, text="얼굴인식", command=run_other1_script, width = 50, height = 5)
button.pack(pady=10)

button = tk.Button(window, text="표정인식", command=run_other2_script, width = 50, height = 5)
button.pack(pady=10)

button = tk.Button(window, text="얼굴등록", command=on_button3_click, width = 50, height = 5)
button.pack(pady=10)


# 이벤트 루프 실행
window.mainloop()
