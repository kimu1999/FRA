import tkinter as tk

# 새로운 Tkinter 창 생성
new_window = tk.Tk()
new_window.title("New Window")
new_window.geometry("300x200")

# 라벨 추가
label = tk.Label(new_window, text="표정인식", font=("Arial", 14))
label.pack(pady=50)

# 이벤트 루프 실행
new_window.mainloop()
