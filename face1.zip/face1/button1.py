import cv2
import tkinter as tk
from tkinter import Label
from PIL import Image, ImageTk

# 얼굴 검출을 위한 Haar Cascade 파일 로드
# face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
cascade_path = r"C:\yhb\Python\face\haarcascade_frontalface_default.xml"
face_cascade = cv2.CascadeClassifier(cascade_path)

# Tkinter 윈도우 생성
window = tk.Tk()
window.title("Real-Time Face Detection")
window.geometry("800x600")

# Tkinter의 라벨을 사용해 비디오 스트림 표시
label = Label(window)
label.pack()

# 웹캠 연결
cap = cv2.VideoCapture(0)

# 웹캠 연결 확인
if not cap.isOpened():
    print("Error: Could not open webcam.")
    window.quit()  # 윈도우 종료

def update_frame():
    # 웹캠에서 프레임 읽기
    ret, frame = cap.read()
    if not ret:
        print("Error: Could not read frame.")
        window.after(10, update_frame)
        return

    # 그레이스케일로 변환
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # 얼굴 검출
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    # 얼굴 검출 결과에 사각형 그리기
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

    # OpenCV 이미지를 PIL 이미지로 변환
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img = Image.fromarray(frame)
    imgtk = ImageTk.PhotoImage(image=img)

    # Tkinter 라벨에 이미지 업데이트
    label.imgtk = imgtk
    label.configure(image=imgtk)

    # 10ms 후 업데이트 반복
    window.after(10, update_frame)

# 업데이트 시작
update_frame()

# 윈도우 닫기 이벤트 처리
def on_closing():
    cap.release()
    window.destroy()

window.protocol("WM_DELETE_WINDOW", on_closing)
window.mainloop()
